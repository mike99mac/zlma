#include <stdint.h>
#include <sys/types.h>
typedef int32_t crypto_int32;

#define select ed25519_select
