int crypto_verify(const unsigned char *x,const unsigned char *y);
